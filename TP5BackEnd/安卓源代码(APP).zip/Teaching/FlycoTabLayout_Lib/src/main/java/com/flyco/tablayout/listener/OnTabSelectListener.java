package com.flyco.tablayout.listener;

public interface OnTabSelectListener {
    void onTabSelect(int position);
    void onTabReselect(int position);
}