package com.wiggins.teaching.ui.view.banners.events;

/**
 * @author S.Shahini
 * @since 11/26/16
 */

public interface OnBannerClickListener {
    void onClick(int position);
}
