package com.wiggins.teaching.ui.view.banners.views;

/**
 * @author S.Shahini
 * @since 12/11/16
 */

public class AttributesManager {

}
