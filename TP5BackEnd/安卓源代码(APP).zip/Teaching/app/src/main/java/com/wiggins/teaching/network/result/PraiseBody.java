package com.wiggins.teaching.network.result;

/**
 * author ：wiggins on 2017/7/28 10:18
 * e-mail ：traywangjun@gmail.com
 * desc :
 * version :1.0
 */

public class PraiseBody {

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String id;
}
