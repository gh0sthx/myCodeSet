package com.wiggins.teaching.ui.view.timepicker;

/**
 * Created by jarylan on 2017/3/29.
 * // 六种选择模式，年月日时分秒，年月日，时分，月日时分，年月，年月日时分
 */

public enum  Type {
    ALL, YEAR_MONTH_DAY, HOURS_MINS, MONTH_DAY_HOUR_MIN, YEAR_MONTH, YEAR_MONTH_DAY_HOUR_MIN
}