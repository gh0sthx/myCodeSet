package com.wiggins.teaching.ui.view.banners.events;

/**
 * @author S.Shahini
 * @since 11/27/16
 */

public interface OnSlideChangeListener {
    void onSlideChange(int selectedSlidePosition);
}
