package com.wiggins.teaching.network.result;

import com.lib.base.net.resultbean.BaseResult;

/**
 * author ：wiggins on 2017/7/25 11:36
 * e-mail ：traywangjun@gmail.com
 * desc :
 * version :1.0
 */

public class UserInfoResult extends BaseResult{

    /**
     * data : XK38dZ8coPYpS27qMt6Av2gFZdJxUZUuam2NW4mpkryGqgvMrQPVfXcfg+TvNToD1pZul9klmFFLEXCgRg8a6R5zSlxJEB0vX8XC8DA1ZjGJr5wr5YgCgU9LfOyFi3AUsVQOBP01oXoG9UFEPGrWJNAnEIVWPKAr6kovitq+b0D45ViviQQ/hwDkDGs7dE+Fbaej5y8nQtonvrrM4a9q4yL/6Wp+KX1rZStqpNd+KHClQfMn04ZnnT5itqEUCyGszqiqwQIBOQlJxhIARjQWyDuEZ48W0XXAcN3X84dnt5vWYQ0d54Rx9Ix78P5QGM66iKcT1GjVcG1de1R/etW+TGwTqhjI/4hy6G/TcF/dHZlfdOX6vvE7JLLuGqOR6NTq
     */

    private String data;

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
