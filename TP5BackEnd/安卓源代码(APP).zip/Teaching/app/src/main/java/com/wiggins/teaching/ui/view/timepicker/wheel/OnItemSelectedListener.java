package com.wiggins.teaching.ui.view.timepicker.wheel;


public interface OnItemSelectedListener {
    void onItemSelected(int index);
}
